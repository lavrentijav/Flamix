"""Плагин для управления Windows Firewall через NetSh"""

import asyncio
import subprocess
import re
import logging
from typing import Dict, Any, Optional
from flamix.api.plugin_interface import PluginInterface

logger = logging.getLogger(__name__)


class NetShPlugin(PluginInterface):
    """Плагин для управления Windows Firewall через NetSh"""
    
    def __init__(self):
        super().__init__()
        self.netsh_path = "netsh"
        self._firewall_enabled = None
    
    async def on_install(self):
        """Вызывается при установке плагина"""
        logger.info(f"[{self.plugin_id}] NetSh plugin installed")
    
    async def on_enable(self):
        """Вызывается при включении плагина"""
        logger.info(f"[{self.plugin_id}] NetSh plugin enabled")
        # Проверяем доступность NetSh
        if not await self._check_netsh_available():
            raise RuntimeError("NetSh is not available on this system")
    
    async def on_init(self, core_api):
        """Вызывается при инициализации плагина"""
        await super().on_init(core_api)
        logger.info(f"[{self.plugin_id}] NetSh plugin initialized")
    
    async def on_disable(self):
        """Вызывается при отключении плагина"""
        logger.info(f"[{self.plugin_id}] NetSh plugin disabled")
    
    async def on_uninstall(self):
        """Вызывается при удалении плагина"""
        logger.info(f"[{self.plugin_id}] NetSh plugin uninstalled")
    
    async def get_health(self) -> Dict[str, Any]:
        """Проверка состояния плагина"""
        try:
            netsh_available = await self._check_netsh_available()
            firewall_state = await self._get_firewall_state()
            
            return {
                "status": "ok" if netsh_available else "error",
                "netsh_available": netsh_available,
                "firewall_enabled": firewall_state.get("enabled", False),
                "firewall_profiles": firewall_state.get("profiles", {})
            }
        except Exception as e:
            logger.error(f"[{self.plugin_id}] Health check failed: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    async def apply_rule(self, rule: Dict[str, Any]) -> Dict[str, Any]:
        """
        Применение правила файрвола через NetSh
        
        Args:
            rule: Словарь с параметрами правила
            
        Returns:
            dict с результатом применения правила
        """
        try:
            # Валидация обязательных полей
            required_fields = ["name", "direction", "action", "protocol"]
            for field in required_fields:
                if field not in rule:
                    return {
                        "success": False,
                        "error": f"Missing required field: {field}",
                        "rule_id": None
                    }
            
            rule_name = rule["name"]
            direction = rule["direction"]  # in или out
            action = rule["action"]  # allow или block
            protocol = rule["protocol"]  # TCP, UDP, ICMP, ANY
            
            # Формируем команду NetSh
            cmd = [
                self.netsh_path,
                "advfirewall",
                "firewall",
                "add",
                "rule"
            ]
            
            # Имя правила
            cmd.extend(["name", rule_name])
            
            # Направление
            cmd.extend(["dir", direction])
            
            # Действие
            cmd.extend(["action", action])
            
            # Протокол
            if protocol.upper() == "ANY":
                cmd.extend(["protocol", "any"])
            else:
                cmd.extend(["protocol", protocol.upper()])
            
            # Локальный порт
            if "local_port" in rule and rule["local_port"]:
                local_port = rule["local_port"]
                if local_port.lower() != "any":
                    cmd.extend(["localport", str(local_port)])
            
            # Удаленный порт
            if "remote_port" in rule and rule["remote_port"]:
                remote_port = rule["remote_port"]
                if remote_port.lower() != "any":
                    cmd.extend(["remoteport", str(remote_port)])
            
            # Локальный IP
            if "local_ip" in rule and rule["local_ip"]:
                local_ip = rule["local_ip"]
                if local_ip.lower() != "any":
                    cmd.extend(["localip", local_ip])
            
            # Удаленный IP
            if "remote_ip" in rule and rule["remote_ip"]:
                remote_ip = rule["remote_ip"]
                if remote_ip.lower() != "any":
                    cmd.extend(["remoteip", remote_ip])
            
            # Профиль
            if "profile" in rule and rule["profile"]:
                profile = rule["profile"]
                if profile.lower() != "any":
                    cmd.extend(["profile", profile.lower()])
            
            # Программа
            if "program" in rule and rule["program"]:
                cmd.extend(["program", rule["program"]])
            
            # Выполняем команду через CoreAPI для безопасности
            if self.core_api:
                # Формируем аргументы (без netsh, так как он передается как command)
                args = cmd[1:]  # Убираем netsh из начала
                
                result = await self.core_api.run_command_safely(
                    self.netsh_path,
                    args
                )
                
                if result.get("returncode") == 0:
                    logger.info(f"[{self.plugin_id}] Rule '{rule_name}' applied successfully")
                    return {
                        "success": True,
                        "rule_id": rule_name,
                        "message": f"Rule '{rule_name}' applied successfully"
                    }
                else:
                    error_msg = result.get("stderr", result.get("stdout", "Unknown error"))
                    logger.error(f"[{self.plugin_id}] Failed to apply rule '{rule_name}': {error_msg}")
                    return {
                        "success": False,
                        "error": error_msg,
                        "rule_id": None
                    }
            else:
                # Fallback: прямой вызов (не рекомендуется, но для совместимости)
                logger.warning(f"[{self.plugin_id}] CoreAPI not available, using direct subprocess call")
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                stdout, stderr = await process.communicate()
                
                if process.returncode == 0:
                    logger.info(f"[{self.plugin_id}] Rule '{rule_name}' applied successfully")
                    return {
                        "success": True,
                        "rule_id": rule_name,
                        "message": f"Rule '{rule_name}' applied successfully"
                    }
                else:
                    error_msg = stderr.decode('utf-8', errors='ignore')
                    logger.error(f"[{self.plugin_id}] Failed to apply rule '{rule_name}': {error_msg}")
                    return {
                        "success": False,
                        "error": error_msg,
                        "rule_id": None
                    }
        
        except Exception as e:
            logger.error(f"[{self.plugin_id}] Error applying rule: {e}", exc_info=True)
            return {
                "success": False,
                "error": str(e),
                "rule_id": None
            }
    
    async def _check_netsh_available(self) -> bool:
        """Проверка доступности NetSh"""
        try:
            if self.core_api:
                result = await self.core_api.run_command_safely(
                    self.netsh_path,
                    ["advfirewall", "show", "allprofiles", "state"]
                )
                return result.get("returncode") == 0
            else:
                # Fallback
                process = await asyncio.create_subprocess_exec(
                    self.netsh_path,
                    "advfirewall",
                    "show",
                    "allprofiles",
                    "state",
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                await process.communicate()
                return process.returncode == 0
        except Exception:
            return False
    
    async def _get_firewall_state(self) -> Dict[str, Any]:
        """Получение состояния Windows Firewall"""
        try:
            if self.core_api:
                result = await self.core_api.run_command_safely(
                    self.netsh_path,
                    ["advfirewall", "show", "allprofiles", "state"]
                )
                
                if result.get("returncode") == 0:
                    output = result.get("stdout", "")
                    profiles = {}
                    enabled = False
                    
                    # Парсим вывод
                    current_profile = None
                    for line in output.split('\n'):
                        line = line.strip()
                        if 'Profile' in line:
                            # Извлекаем имя профиля
                            match = re.search(r'Profile\s+(\w+)', line)
                            if match:
                                current_profile = match.group(1).lower()
                                profiles[current_profile] = {"enabled": False}
                        elif 'State' in line and current_profile:
                            if 'ON' in line:
                                profiles[current_profile]["enabled"] = True
                                enabled = True
                    
                    return {
                        "enabled": enabled,
                        "profiles": profiles
                    }
            
            return {"enabled": False, "profiles": {}}
        except Exception as e:
            logger.error(f"[{self.plugin_id}] Error getting firewall state: {e}")
            return {"enabled": False, "profiles": {}}


# Экспортируем класс плагина
Plugin = NetShPlugin
